<!DOCTYPE html>
<html class="" style=""><!--<![endif]--><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title>Quiz Changllenge!</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="../assets/grocery_crud/css/slidercss/bootstrap.css">
	<!-- Font Awesome -->
	<link rel="stylesheet" type="text/css" href="../assets/grocery_crud/css/slidercss/font-awesome.min.css">
	<!--[if IE 7]>
		<link rel="stylesheet" type="text/css" href="../css/font-awesome-ie7.min.css">
	<![endif]-->
	<!-- End Font Awesome -->
	<!-- Menu Styles -->
	<!--[if (gt IE 9)|!(IE)]><!-->
		<link rel="stylesheet" type="text/css" href="../assets/grocery_crud/css/slidercss/fading.css" media="screen">
	<!--<![endif]-->
	<!-- End Menu Styles -->
	<link rel="stylesheet" type="text/css" href="../assets/grocery_crud/css/slidercss/main.css">
	<link rel="stylesheet" type="text/css" href="../assets/grocery_crud/css/slidercss/css" id="custom_font">
	<!--[if lte IE 8]>
		<script type="text/javascript" src="../js/vendor/selectivizr.min.js"></script>
		<script type="text/javascript" src="../js/vendor/respond.min.js"></script>
	<![endif]-->
	
	<script type="text/javascript" src="../assets/grocery_crud/css/slidercss/modernizr.min.js"></script>
	<script src="../assets/grocery_crud/css/slidercss/jquery.min.js"></script>
	<script type="text/javascript" src="../assets/grocery_crud/css/slidercss/bootstrap.min.js"></script>
	
	<link rel="stylesheet" href="../assets/grocery_crud/css/slidercss/sliding.quiz.css" type="text/css" media="screen">
	<script type="text/javascript" src="../assets/grocery_crud/css/slidercss/sliding.quiz2.js"></script>



	<link rel="stylesheet" type="text/css" href="../assets/grocery_crud/css/slidercss/prettify.css">


</head>
<body class="wide">

<script>
  window.fbAsyncInit = function() {
    FB.init({
      appId      : '899062426877511',
      xfbml      : true,
      version    : 'v2.5'
    });
  };

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "//connect.facebook.net/en_US/sdk.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
</script>

<h1 id="fb-welcome"></h1>

<script>
// Only works after `FB.init` is called
function myFacebookLogin() {
  FB.login(function(){}, {scope: 'publish_actions'});
}

FB.login(function(){
  // Note: The call will only work if you accept the permission request
  FB.api('/me/feed', 'post', {message: 'Hackademics Facebook app!'});
}, {scope: 'publish_actions'});

</script>
<button onclick="myFacebookLogin()">Login with Facebook</button>

		<!-- Header -->

		
							<!-- Single Page -->
								<div class="page">



		<div id="quiz-content" class="quiz-content"><div class="quiz-wrapper" id="quiz-instruction-container" style="display: none;">
                    <div class="steps" style="width: 12600px;">
                    <form id="822182512">
                    <fieldset class="step"><legend>CSS Quiz</legend><div style="padding: 20px 10px;">Test your knowledge of CSS with our CSS Quiz, the test currently contains 20 questions. You will get 1 point for each correct answer. At the end of the Quiz, your total score will be displayed. Maximum score is 20 points. If you don't get the full score, you'll have an option to try again.<br><br>Start the quiz now by clicking on the button below.</div></fieldset></form></div>
                    <div id="quiz-navigation" style=""><ul style="float:right;margin-right:20px;"><li><a href="javascript:;;" id="btn-start-quiz">Start</a></li></ul></div>
					
                    </div>
					
					<div class="quiz-wrapper hide_container" style="display: block;"><div class="steps" style="width: 12600px;"><form id="formElem" name="formElem" action="" method="post"><fieldset class="step show" question="1" choice="1"><legend>What is the correct CSS syntax for making all the &lt;span&gt; elements bold?</legend><p answer="1" class="selected">span {text-size:bold}</p><p answer="2">span {font-weight:bold}</p><p answer="3">&lt;span style="font-size:bold"&gt;</p><p answer="4">&lt;span style="text-size:bold"&gt;</p></fieldset></form>
					
					
					</div><div id="quiz-notice"><span class="label label-important"><i class="qicon-exclamation-sign qicon-white"></i>&nbsp;Please select an answer</span></div><div id="quiz-navigation" style=""><ul><li class="disabled"><a href="../assets/grocery_crud/css/slidercss/CSS Quiz - CSS Portal.htm" id="back-quiz">Back</a></li><li class="page-number"><a href="../assets/grocery_crud/css/slidercss/CSS Quiz - CSS Portal.htm">1/20</a></li><li class=""><a href="../assets/grocery_crud/css/slidercss/CSS Quiz - CSS Portal.htm" id="next-quiz">Next</a><a href="../assets/grocery_crud/css/slidercss/CSS Quiz - CSS Portal.htm" id="finish-quiz" style="display: none;"><i class="qicon-asterisk qicon-white"></i>&nbsp;Finish</a></li></ul></div><div class="progress-container"><div class="progress"></div></div></div></div>
		
		<div class="clear"></div>
		<div style="text-align:center;">
		<hr>
										<div class="image">
										<style>
										.css-responsive { width: 320px; height: 50px; }
										@media(min-width: 500px) { .css-responsive { width: 468px; height: 60px; } }
										@media(min-width: 1200px) { .css-responsive { width: 728px; height: 90px; } }
										</style>
										<!-- CSS Responsive -->
										
								</div>		<hr>						
		</div>
		<script type="text/javascript">
		/*slide quiz*/

		$(function()
		    {

		        $("#quiz-content").sliding_quiz ({
					 'instruction':
					 {
					 	'title': 'CSS Quiz',
					 	'description' : 'Test your knowledge of CSS with our CSS Quiz, the test currently contains 20 questions. You will get 1 point for each correct answer. At the end of the Quiz, your total score will be displayed. Maximum score is 20 points. If you don\'t get the full score, you\'ll have an option to try again.<br /><br />Start the quiz now by clicking on the button below.'
					 },
					'questions':
					[
					
					<?php
    $conn=mysql_connect("localhost", "learningonfbcf73", "0e1ab76c7542d6849") or die("can't connect database");
    mysql_select_db("learningonfb_cf_73",$conn);
    $sql="SELECT * FROM quiz ORDER BY RAND()";
    $query=mysql_query($sql);
    if(mysql_num_rows($query) == 0){
        echo "Chua co du lieu";
    }
    else{
        while($row=mysql_fetch_array($query)){
            
       ?>
                         {
                            'id'        :  <?php echo trim($row['questionnum']); ?>,
                            'question'  : '<?php echo trim($row['question']); ?>',
                            'answers'   : ['<?php echo trim($row['option1']); ?>','<?php echo $row['option2']; ?>','<?php echo $row['option3']; ?>','<?php echo trim($row['option4']); ?>'],
                            'weight'     : <?php if (trim($row['correctans'])=="1") {echo "[1,0,0,0]"; } elseif (trim($row['correctans'])=="2") {echo "[0,1,0,0]"; } elseif (trim($row['correctans'])=="3") {echo "[0,0,1,0]"; } elseif (trim($row['correctans'])=="4") {echo "[0,0,0,1]"; } ?>,
                        },
                    
                 
				 <?php 
				  }
    }
    mysql_close($conn);
?>
				 
				 
                        {
                            'id'        : 4,
                            'question'  : 'How do you display hyperlinks without an underline?',
                            'answers'   : ['a {decoration:no underline}', 'a {text-decoration:none}','a {hyperlink:no underline}', 'a {text-decoration:no underline}'],
                            'weight'     : [0, 1, 0, 0],
                        }
					],
					'locale': //optional
					{
						'msg_not_found' : 'Cannot find questions',
						'msg_please_select_an_option' : 'Please select an answer',
						'msg_question' : 'Question',
						'msg_you_scored' : 'You scored',
						'msg_click_to_review' : 'Click the question button to review your answers',
						'bt_next' : 'Next',
						'bt_back' : 'Back',
						'bt_finish' : 'Finish',
						'bt_contact' : 'Submit Your Score',
						'contact_heading' : 'Submit Your Score'
					},
					'when_finish_submit_url': '',
					'contact_form_submit_url': '',
					//'effect': 'fade'
				});
			});
		</script>



								</div>
								<!-- End Single Page -->

	
	
	<!--[if lte IE 9]>
		<script type="text/javascript" src="../js/vendor/jquery.placeholder.min.js"></script>
		<script type="text/javascript" src="../js/vendor/jquery.menu.min.js"></script>
		<script type="text/javascript">
			/* <![CDATA[ */
			jQuery.noConflict();

			(function ($) {
				$(function () {
					// Menu effect
					$('#nav .menu').menu({'effect' : 'fade'});
				});
			})(jQuery);
			/* ]]> */
		</script>
	<![endif]-->
	<script type="text/javascript" src="../assets/grocery_crud/css/slidercss/plugins.js"></script>
	<script type="text/javascript" src="../assets/grocery_crud/css/slidercss/main.js"></script>


</body></html>